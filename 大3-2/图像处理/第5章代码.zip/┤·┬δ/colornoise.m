function [R, G, B, I] = colornoise(f, mean, std)
% % [R,G,B,I] = colornoise(rgb, mean, std)  %RGB图像，均值，标准差

[M,N,C] = size(f);
r = f(:,:,1);
g = f(:,:,2);
b = f(:,:,3);
noise = normrnd(mean, std, M, N);
R = double(r) + noise;
R = uint8(round(R));
G = double(g) + noise;
G = uint8(round(G));
B = double(b) + noise;
B = uint8(round(B));
I = double(f) + noise;
I = uint8(round(I));
end