clear all
close all
clc

r1 = imread('Fig0624(a)RGB2-red.tif');
subplot(2,6,1);
imshow(r1);

g1 = imread('Fig0624(b)RGB2-green.tif');
subplot(2,6,2);
imshow(g1);

b1 = imread('Fig0624(a)RGB2-red.tif');
subplot(2,6,3);
imshow(b1);

rgb1 = cat(3, r1, g1, b1);
subplot(2,6,4);
imshow(rgb1);

[VG1, A1, PPG1] = colorgrad(rgb1);
subplot(2,6,5);
imshow(VG1,[]); title('RGB向量梯度');
subplot(2,6,6);
imshow(PPG1,[]); title('对单独彩色平面的二维梯度求和形成的梯度');

r2 = imread('Fig0624(a)RGB2-red.tif');
subplot(2,6,7);
imshow(r2);

g2 = imread('Fig0624(b)RGB2-green.tif');
subplot(2,6,8);
imshow(g2);

b2 = imread('Fig0624(c)(RGB2-blue).tif');
subplot(2,6,9);
imshow(b2);

rgb2 = cat(3, r2, g2, b2);
subplot(2,6,10);
imshow(rgb2);

[VG2, A2, PPG2] = colorgrad(rgb2);
subplot(2,6,11);
imshow(VG2,[]);title('RGB向量梯度');
subplot(2,6,12);
imshow(PPG2,[]);title('分别对RGB平面的二维梯度求和形成的梯度');