clear all
close all
clc
% shift 加鼠标点击，增加控制点
ff = imread('Fig0604(a)(iris).tif');
% ff = rgb2gray(f);
ice('image', ff) 