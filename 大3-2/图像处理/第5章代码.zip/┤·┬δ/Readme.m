% 可运行的main函数
% ice.m: 手动读入图像，参考函数的说明，运行此程序
% coloredge.m 可以直接运行，其他都为function