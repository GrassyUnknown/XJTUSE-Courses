#include "Figure.h"
#include"Graphics.h"
#include<iostream>
using namespace std;
 
Point::Point(int x, int y): Location(x, y)
{
	visible = false;							// 缺省情况下点是不可见的
}
 
bool Point::is_visible()
{
	return visible;
}
void Point::show(HDC hdc)
{
	if (! is_visible()) {
		visible = true;
		HBRUSH hBrush = CreateSolidBrush(RGB(200, 256,256));	
		point(hdc,hBrush,x_pos,y_pos);
	}
}
void Point::hide(HDC hdc)
{
	if (is_visible()) {
		visible = false;
		HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));	
		point(hdc,hBrush,x_pos,y_pos);	
	}
}
void Point::move_to(HDC hdc,int x, int y)
{
	hide(hdc);									
	x_pos = x;								
	y_pos = y;
	show(hdc);									
}