 
#include"Graphics.h"
#define MY_BUFSIZE 100
HWND getConsoleHwnd(void)
{  
	char pszNewWindowTitle[MY_BUFSIZE]; // Contains fabricated  
	char pszOldWindowTitle[MY_BUFSIZE]; // Contains original  
	GetConsoleTitle(pszOldWindowTitle, MY_BUFSIZE);  
	wsprintf(pszNewWindowTitle,"%d/%d", GetTickCount(),  GetCurrentProcessId());  
	SetConsoleTitle(pszNewWindowTitle);  
	Sleep(40);  
	HWND hConsole=FindWindow(NULL, pszNewWindowTitle);  
	SetConsoleTitle(pszOldWindowTitle); 
	return hConsole;
}
void circle(HDC hdc, HPEN hPen,int cx, int cy, int r)
{
	SelectObject(hdc, hPen);
	Arc(hdc,cx-r,cy-r,cx+r,cy+r,cx-r,cy,cx+r,cy);
	Arc(hdc,cx-r,cy-r,cx+r,cy+r,cx+r,cy,cx-r,cy);
}
void point(HDC hdc, HBRUSH hBrush,int cx, int cy)
{
	HPEN hpen = CreatePen(0, 5, RGB(0, 0, 0));
	SelectObject(hdc, hpen);
	(HPEN)SelectObject(hdc,hBrush);
	Ellipse(hdc,cx,cy,cx+50,cy+50);
}
void line(HDC hdc, HPEN hpen, int sx, int sy, int ex, int ey)
{
	SelectObject(hdc, hpen);
	(HPEN)SelectObject(hdc,hpen);
	MoveToEx(hdc,sx,sy,NULL); 
	LineTo(hdc,ex,ey);
}
void rect(HDC hdc, HPEN hpen, int left, int top, int right, int bottom)
{
	SelectObject(hdc, hpen);
	(HPEN)SelectObject(hdc,hpen);
	Rectangle(hdc,left,top,right,bottom);
}