#pragma once
 
#include<Windows.h>
//函数功能：获得控制台窗口句柄
HWND  getConsoleHwnd(void);
//函数功能：在窗口上用创建的hpen画笔以（cx，cy）为圆心，r为半径画圆
void  circle(HDC, HPEN hpen,int cx, int cy, int r);
//函数功能：在窗口上用创建的画刷画坐标为(lx，ly)点*/
void  point(HDC, HBRUSH hbrush,int lx, int ly);
//函数功能：在窗口上用创建的画笔画出以(sx,sy)作为起点，(ex,ey)作为终点的一条直线
void  line(HDC hdc, HPEN hpen, int sx, int sy, int ex, int ey);
//函数功能：在窗口上用创建的画笔画出以（left,top）为左上角坐标，(right,bottom)为右下角坐标的矩形
void  rect(HDC hdc, HPEN hpen, int left, int top, int right, int bottom);