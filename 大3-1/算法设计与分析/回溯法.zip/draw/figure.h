#include<Windows.h>
class Figure{
public:
	virtual void show(HDC) = 0;
};
class Location{
public:
	Location(){}
	Location(int x, int y);
	int get_x();
	int get_y();
	int x_pos, y_pos;
};
class Point: public Location, public Figure{
public:
	Point(){}
	Point(int x, int y);
	bool is_visible();
	void show(HDC hdc);
	void hide(HDC hdc);
	void move_to(HDC hdc,int x, int y);
	bool visible;
};
class Circle: public Point{
public:
	Circle(){}
	Circle(int x, int y, int r);
	void show(HDC hdc);
	void hide(HDC hdc);
	void move_to(HDC hdc,int x, int y);
	void set(int x, int y, int r);
	int radius;
};
class Rect:public Figure{
private:
	int lx, ly, rx, ry;
public:
	Rect(int lx, int ly, int rx, int ry);
	void show(HDC);
};
class Tria:public Figure{
private:
	int lx, ly, rx, ry,tx,ty;
public:
	Tria(int lx, int ly, int rx, int ry,int tx, int ty);
	void show(HDC);
};