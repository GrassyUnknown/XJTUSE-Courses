#include "Figure.h"
#include"Graphics.h"
#include<iostream>
#include<Windows.h>
using namespace std;
Circle::Circle(int x, int y, int r): Point(x, y)
{
	radius = r;
}
void Circle::show(HDC hdc)
{
	if (! is_visible()) {
		visible =true;
		HPEN hpen = CreatePen(0, 5, RGB(200, 256,256));
		circle(hdc,hpen,x_pos,y_pos,radius);
	}
}
void Circle::hide(HDC hdc)
{
	if (is_visible()) {
		visible=false;
		HPEN hpen = CreatePen(0, 5, RGB(0, 0, 0));
		circle(hdc,hpen,x_pos,y_pos,radius);			
	}
}
void Circle::move_to(HDC hdc,int x, int y)
{
	hide(hdc);								
	x_pos = x;							
	y_pos = y;
	show(hdc);								
}


void Circle::set(int x, int y, int r)
{
	x_pos = x;
	y_pos = y;
	radius = r;
}

