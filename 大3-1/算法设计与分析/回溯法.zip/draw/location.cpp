 
#include "Figure.h"
 
Location::Location(int x, int y)
{
	x_pos = x;
	y_pos = y;
}
 
int Location::get_x()
{
	return x_pos;
}
 
int Location::get_y()
{
	return y_pos;
}