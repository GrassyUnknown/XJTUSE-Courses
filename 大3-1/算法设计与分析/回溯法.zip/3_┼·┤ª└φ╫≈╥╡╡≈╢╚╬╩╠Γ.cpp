#define MAX 200
#include<iostream>
using namespace std;

int number;//作业数量
int x1[10];//作业在机器1运行的时间
int x2[10];//作业在机器2运行的时间
int sum = 0;//作业完成的总时间 
int bestsum = MAX;//作业完成的最优时间 
int order[10];//作业完成的次序,要用于交换
int bestorder[10];//作业完成的最优的顺序
int f1 = 0;//机器1累计的时间 
int f2[10];//作业在机器2处理完累计的时间，即每一个作业的调度时间
int vis[10];//记录作业以否已被选 

//void backtrack(int cur) {//cur表示正在赋值的位置，cur+1去到下一层子节点，i递增，在当前层遍历兄弟节点
//	if(cur>number)
//	{
//		for(int i=0; i<number; i++) 
//			bestorder[i]=order[i];
//		bestsum=sum;
//	} 
//	else {
//		for(int i=0; i<number; i++)
//		{ //遍历number，尝试填第一位
//			if(!vis[i]) 
//			{
//				vis[i] = 1;
//				f1+=x1[i];
//				//本作业的在机器1的处理时间 和 上一个作业在机器2的处理时间的较大时间（因为两者是同时进行的）
//				f2[cur]=( f2[cur-1] > f1 ? f2[cur-1] : f1) + x2[i];
//				sum+=f2[cur];
//				order[cur] = i;
//				if(sum<bestsum) {//剪枝，如果当前sum都大于bestsum了，则不再遍历此节点 
//					backtrack(cur+1);
//				}
//				//每计算一次，为了不影响父节点和兄弟节点，运算完都要复位
//				sum-=f2[cur];
//				f1-=x1[i];
//				vis[i] = 0;
//			}
//		}
//	}
//}

void backtrack(int cur)
{
    //到达边界 
    if(cur >= number)
	{
        for(int i=0; i<number; i++)
		{
            bestorder[i] = order[i];
        }
        bestsum = sum;
    }
	else{
        //cur表示正在赋值的位置，cur+1去到下一层子节点，i递增，在当前层遍历兄弟节点 
        for(int i=cur; i<number; i++)
		{
            f1 += x1[order[i]];
			if (cur >0)
			{
				f2[cur] = (f2[cur - 1] > f1 ? f2[cur -1] : f1) + x2[order[i]];
			}
			else
			{
				f2[cur] = f1 + x2[order[i]];
			}

            sum += f2[cur];
            /*例如cur为2，i=3时，表示正在为作业队列的第2个位置赋作业3的值，所以此时的队列作业顺序应该是{1，3,2}, 所以要把i和cur的位置换掉；
            同理例如cur为1，i=2时，表示正在为作业队列的第1个位置赋作业2的值，此时的顺序是{2，1,3}，好好理解这一点 
            swap函数就是要做这个事情
            */ 
            swap(order[cur], order[i]);
            if(sum < bestsum){//剪枝，如果当前sum都大于bestsum了，则不再遍历此节点 
                backtrack(cur+1);
            }

            swap(order[cur], order[i]);
            sum -= f2[cur];
            f1 -= x1[order[i]];
        }
    }
}

int main() {
	//cout << "请输入作业的数量： "; 
	//cin >> number;
	//int i;
	//cout << "请输入每个作业在机器1的运行时间：" << endl;
	//for(i=1; i<=number; i++){
	//	cin >> x1[i];
	//}
	//cout << endl << "请输入每个作业在机器2的运行时间：" << endl;
	//for(i=1; i<=number; i++){
	//	cin >> x2[i];
	//}
	number = 3;
	x1[0] = 2;
	x1[1] = 3;
	x1[2] = 2;
	x2[0] = 1;
	x2[1] = 1;
	x2[2] = 3;

	//初始化第一个序列，从1开始到number 
	for(int i=0; i<number; i++)
	{
		order[i] = i;
	}
	backtrack(0);
	cout<<"最节省的时间为："<<bestsum<<endl;  
	cout<<"对应的方案为：";  
	for(int i=0;i<number;i++) 
		cout<<bestorder[i]<<"  ";  
	cout<<endl;  
	system("pause");
}