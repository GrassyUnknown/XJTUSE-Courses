#include <iostream>

using namespace std;

int a[3];


void Backtrack(int t) {
	if (t > 3) {
		for (int i = 0; i < 3; i++) {
			cout << a[i] << " ";
		}
		cout << endl;
		return ; 
	}
	else {
		for (int i = t; i <= 3; i++) {
			int temp = a[i - 1];
			a[i - 1] = a[t - 1];
			a[t - 1] = temp;
			Backtrack(t + 1);
			temp = a[i - 1];
			a[i - 1] = a[t - 1];
			a[t - 1] = temp;
		}
	}
}

int main() {
	a[0] = 2;
	a[1] = 3;
	a[2] = 4;

	Backtrack(1);

	system("pause");
}
