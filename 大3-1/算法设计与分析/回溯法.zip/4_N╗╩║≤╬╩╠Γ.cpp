#include <iostream>
#include <cmath>
int x[2000];
int n,count;
int Place(int k)
{
	int j;
	for(j=0;j<k;j++)
		if((abs(k-j)==abs(x[j]-x[k]))||(x[j]==x[k]))
			return 0;
	return 1;
}
void Backtrack(int t)
{
	int i;
	if(t>=n) 
	{
		for(i=0;i<n;i++)
			printf("%d ",x[i]+1);
		printf("\n");
		count++;
	}
	else
		for(i=0;i<n;i++) 
		{
			x[t]=i;
			if(Place(t))
				Backtrack(t+1);
		}
}
int main()
{
	printf("请输入n:");
	scanf("%d",&n);
	Backtrack(0);
	printf("共%d组答案\n",count);
	system("pause");
	return 0;
}